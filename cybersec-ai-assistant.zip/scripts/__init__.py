"""
Scripts utilitaires pour CyberSec AI Assistant
==============================================
"""